package com.example.assignment4;

import android.os.Bundle;
import android.view.View;
import android.widget.*;

import android.content.Intent;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class FourthActivity extends AppCompatActivity {
    TextView textView10;
    TextView textView9;
    public static final String newkey = "user";
    Button button5;
    RadioGroup radioGroup2;
    RadioButton radioButton4;
    RadioButton radioButton5;
    RadioButton radioButton6;
    EditText editTextText3;
    EditText editTextText4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_fourth);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button button5 = findViewById(R.id.button5);
        RadioGroup radioGroup2 = findViewById(R.id.radioGroup2);
        EditText editTextText3 = findViewById(R.id.editTextText3);
        EditText editTextText4 = findViewById(R.id.editTextText4);
        findViewById(R.id.button5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String role = "";
                int checkedId = radioGroup2.getCheckedRadioButtonId();
                if (checkedId == R.id.radioButton4) {
                    role = "Student";
                }
                if (checkedId == R.id.radioButton5) {
                    role = "Employee";
                }
                if (checkedId == R.id.radioButton6) {
                    role = "Other";
                }
                String name = editTextText3.getText().toString();
                String email = editTextText4.getText().toString();
                if (name.isEmpty()) {
                    Toast.makeText(FourthActivity.this, "Enter name", Toast.LENGTH_SHORT).show();
                }
                else if (email.isEmpty()) {
                    Toast.makeText(FourthActivity.this, "Enter email", Toast.LENGTH_SHORT).show();

                } else {
                    User user = new User(name, email, role);
                    Intent intent = new Intent();
                    intent.putExtra(newkey, user);
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }
        });
    }
}