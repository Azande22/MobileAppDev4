package com.example.assignment4;

import android.content.Intent;
import android.os.Bundle;

import android.provider.MediaStore;
import android.view.View;
import android.widget.*;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SecondActivity extends AppCompatActivity {
    EditText editTextText;
    EditText editTextText2;
    Button button;
    RadioGroup radioGroup;
    RadioButton radioButton;
    RadioButton radioButton2;
    RadioButton radioButton3;
    public static final String key = "USER";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_second);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        EditText editTextText = findViewById(R.id.editTextText);
        EditText editTextText2 = findViewById(R.id.editTextText2);
        Button button = findViewById(R.id.button);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        RadioButton radioButton = findViewById(R.id.radioButton);
        RadioButton radioButton2 = findViewById(R.id.radioButton2);
        RadioButton radioButton3 = findViewById(R.id.radioButton3);
        User user = new User();

        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user_name = editTextText.getText().toString();
                String user_email = editTextText2.getText().toString();
                user.name = user_name;
                user.email = user_email;
                int checkedId = radioGroup.getCheckedRadioButtonId();
                if (checkedId == R.id.radioButton) {
                    user.setRole("Student");
                }
                if (checkedId == R.id.radioButton2) {
                    user.setRole("Employee");
                }
                if (checkedId == R.id.radioButton3) {
                    user.setRole("Other");
                }
                if (user_name.isEmpty()) {
                    Toast.makeText(getBaseContext(), "Please enter a name!", Toast.LENGTH_SHORT).show();
                }
                if (user_email.isEmpty()) {
                    Toast.makeText(getBaseContext(), "Please enter an email!", Toast.LENGTH_SHORT).show();
                }
                Intent intent = new Intent(SecondActivity.this, ThirdActivity.class);
                intent.putExtra(key, user);
                startActivity(intent);
            }
        });
    }
}